'use strict';

/**
 * ongoingpromo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::ongoingpromo.ongoingpromo', ({strapi}) => ({
    async findOne(ctx){
        const { slug } = ctx.params;

        const entity =  await strapi.db.query('api::ongoingpromo.ongoingpromo').findOne({
            where: {slug},
            populate: {
                mediaImage: {
                    populate: {
                      fields: ['*'],
                    }
                  },
				  mobileBannerImage: {
                    populate: {
                      fields: ['*'],
                    }
                  },
				  carouselTxtImg: {
					populate: {
					cardImage: {
                    populate: {
                      fields: ['*'],
                    }
                }
              }
                  },
				    classBoxes: {
					populate: {
					cardImage: {
                    populate: {
                      fields: ['*'],
                    }
                }
              }
                  },
				   services1: {
                                        populate:{
                                                   serviceimage:{
                                                           populate:{
                                                                   fields: ['*']
                                                           }
                                                   }
                                           }
                                  },
		    services2: {
					populate:{
						   serviceimage:{
							   populate:{
								   fields: ['*']
							   }
						   }
					   }
				  },
		    faqs: {
			    populate:{
				    fields: ['*']
			    }
		    },
		    airportTabs: {
			populate: {
				fields: ['*']
			}
		    }
				  
            }
        });
        const sanitizedEntity = await this.sanitizeOutput(entity);

        return this.transformResponse(sanitizedEntity);
    }
}));

  


