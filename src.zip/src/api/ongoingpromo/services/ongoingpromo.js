'use strict';

/**
 * ongoingpromo service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::ongoingpromo.ongoingpromo');
