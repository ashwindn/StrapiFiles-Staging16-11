module.exports = {
    routes: [
        {
            method: 'GET',
            path: '/ongoingpromos/:slug',
            handler: 'ongoingpromo.findOne',
            config: {
                auth: false,
            }
        }

    ]
}
