'use strict';

/**
 *  deal controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::deal.deal');
