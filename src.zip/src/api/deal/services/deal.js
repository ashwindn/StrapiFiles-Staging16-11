'use strict';

/**
 * deal service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::deal.deal');
