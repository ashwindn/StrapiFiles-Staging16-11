'use strict';

/**
 * job-opening controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::job-opening.job-opening');
