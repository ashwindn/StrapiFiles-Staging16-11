'use strict';

/**
 *  param controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::param.param');
