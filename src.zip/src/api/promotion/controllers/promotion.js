'use strict';

/**
 * promotion controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::promotion.promotion', ({strapi}) => ({
  async findOne(ctx){
      const { slug } = ctx.params;

      const entity =  await strapi.db.query('api::promotion.promotion').findOne({
          where: {slug},
          
          populate: {
              breadcrumbs: {
                populate: {
                  fields: ['*'],
                }
              },
              promoCard: {
                populate: {
                  cardImage: {
                    populate: {
                      fields: ['*'],
                    }
                }, 
                cardIcon: {
                  populate: {
                    fields: ['*'],
                  }
              },
              }
            }, 
              mediaImage: {
                populate: {
                  fields: ['*'],
                }
              },
	      mediaImageMobile: {
		populate: {
			fields: ['*'],
		}
	      },
              seo: {
                populate: {
                  fields: ['*'],
                }
              }
            },
            
          
      });
      const sanitizedEntity = await this.sanitizeOutput(entity);

      return this.transformResponse(sanitizedEntity);
  }
}));
