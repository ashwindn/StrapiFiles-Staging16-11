module.exports = {
    routes: [
        {
            method: 'GET',
            path: '/promotions/:slug',
            handler: 'promotion.findOne',
            config: {
                auth: false,
            }
        }

    ]
}