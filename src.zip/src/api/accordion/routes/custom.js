module.exports = {
    routes: [
        {
            method: 'GET',
            path: '/accordions/:slug',
            handler: 'accordion.findOne',
            config: {
                auth: false,
            }
        }

    ]
}
