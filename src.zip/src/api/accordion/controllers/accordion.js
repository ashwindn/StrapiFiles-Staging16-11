'use strict';

/**
 * promotion controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::accordion.accordion', ({strapi}) => ({
  async findOne(ctx){
      const { slug } = ctx.params;

      const entity =  await strapi.db.query('api::accordion.accordion').findOne({
          where: {slug},
          
          populate: {
            accordian: {
                populate: {
                  fields: ['*'],
                }
              }
            },
            
          
      });
      const sanitizedEntity = await this.sanitizeOutput(entity);

      return this.transformResponse(sanitizedEntity);
  }
}));

