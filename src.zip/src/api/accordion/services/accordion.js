"use strict";

/**
 *  accordion controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::accordion.accordion");

