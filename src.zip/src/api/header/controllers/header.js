'use strict';

/**
 *  header controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::header.header');
