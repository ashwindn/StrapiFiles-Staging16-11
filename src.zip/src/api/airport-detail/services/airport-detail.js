'use strict';

/**
 * airport-detail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::airport-detail.airport-detail');
