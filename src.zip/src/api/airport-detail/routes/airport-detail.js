'use strict';

/**
 * airport-detail router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::airport-detail.airport-detail');
